Z='green'
Y='red'
X='error: '
W=range
U='r'
T=True
S='>'
R='grey'
O='\n'
N=open
M=len
J=False
I='bold'
G=str
F=''
E=' '
C=print
B=int
from sys import argv as K,exit as H
from os import system as a
from os.path import dirname as b
from time import sleep
from termcolor import cprint as A,colored as L
from tabulate import tabulate as c
from random import randint as P
def err(message):A(f"cend1: ",attrs=[I],end=F);A(X,Y,attrs=[I],end=F);C(message);H(-1)
class d:
	def suppressErrors(A):A.suppressError=B(1)
	def err(B,message,lines=0):
		if not bool(B.suppressError):A(f"cend1",attrs=[I],end=F);A(f"[line:{lines}]: ",R,end=F);A(X,Y,attrs=[I],end=F);C(message);H(1)
		else:0
	def toInt(A,x):
		try:A.setd(x,B(A.variables[x][1]))
		except ValueError:A.err('Value could not be converted into an int.',A.lines)
	def __init__(A):D='_';A.variables={'TRUE':(B,1),'FALSE':(B,0)};A.functions={};A.suppressError=B(0);A.QUOTE='"';A.COMMANDS={':println':lambda*B:C(E.join(B)[1:])if B[0][0]==D else C(L(f"{B[0]}: <"+A.variables[B[0]][1].__class__.__name__+S,R),A.variables[B[0]][1]),':print':lambda*B:C(E.join(B)[1:],end=E)if B[0][0]==D else C(L(f"{B[0]}: <"+A.variables[B[0]][1].__class__.__name__+S,R),A.variables[B[0]][1],end=E),':rawprint':lambda*B:C(E.join(B)[1:],end=E)if B[0][0]==D else C(A.variables[B[0]][1],end=E),':rawprintln':lambda*B:C(E.join(*B)[1:],end=O)if B[0][0]==D else C(A.variables[B[0]][1],end=O),':rawrawprint':lambda*B:C(F.join(B)[1:],end=F)if B[0][0]==D else C(A.variables[B[0]][1],end=F),':set':lambda*B:A.setd(B[0],E.join(B[1:])),':setadd':lambda x,y,z,mode=B,*B:A.setd(x,mode(y[1:])+mode(z[1:]))if y[0]==D and z[0]==D else A.setd(x,A.variables[y][1]+A.variables[z][1]),':setminus':lambda x,y,z,mode=B,*B:A.setd(x,mode(y[1:])-mode(z[1:]))if y[0]==D and z[0]==D else A.setd(x,A.variables[y][1]-A.variables[z][1]),':setdiv':lambda x,y,z,mode=B,*B:A.setd(x,mode(y[1:])//mode(z[1:]))if y[0]==D and z[0]==D else A.setd(x,A.variables[y][1]//A.variables[z][1]),':setmult':lambda x,y,z,mode=B,*B:A.setd(x,mode(y[1:])*mode(z[1:]))if y[0]==D and z[0]==D else A.setd(x,A.variables[y][1]*A.variables[z][1]),':setpow':lambda x,y,z,mode=B,*B:A.setd(x,mode(y[1:])**mode(z[1:]))if y[0]==D and z[0]==D else A.setd(x,A.variables[y][1]**A.variables[z][1]),':setnot':lambda x,y,*B:A.setd(x,abs(A.variables[y][1]-1)),':setstr':lambda x,y,*B:A.setd(x,y,typse=G),':setgreater':lambda x,y,z:A.setd(x,y,B(y>z))if y[0]==D else A.setd(x,B(A.variables[y]>A.variables[z])),':setequals':lambda x,y,z:A.setd(x,y,B(y==z))if y[0]==D else A.setd(x,B(A.variables[y]==A.variables[z])),':settype':lambda x,y:A.setd(x,A.variables[y][1].__class__.__name__,typstr=T),':if':lambda x,*B:A.run(E.join(B),countLines=J)if A.variables[x][1]==1 else 0,':repeat':lambda x,*C:A.reprun(E.join(C),B(x)),':setconcat':lambda x,y,z,*B:A.setd(x,A.variables[y][1]+A.variables[z][1],typstr=T),':copyvar':lambda x,y:A.setd(x,A.variables[y][1]),':content':lambda file:C(A.content(file)),':display':lambda*B:C(A.variables),':rand100':lambda*B:A.setd('rand100',P(0,100)),':rand1000':lambda*B:A.setd('rand1000',P(0,1000)),':rand10':lambda*B:A.setd('rand10',P(0,10)),':clear':lambda*A:a('clear'),':getarguments':lambda*B:A.setd('args',K[2:]+['0']*20,typse=list),':toint':A.toInt,':end':lambda*A:H(0),':wait':lambda t,*A:sleep(B(t)/1000),':fun':A.addFunction,':displayfn':lambda*B:C(A.functions),':suppress':A.suppressErrors,':keys':lambda*B:C(c([A.COMMANDN[B:B+4]for B in W(0,M(A.COMMANDN),4)])),':incr':lambda x,*B:A.setd(x,A.variables[x][1]+1),':zero':lambda x,*B:A.setd(x,0),':err':lambda*B:A.err(E.join(B),A.lines)};A.COMMANDN=list(A.COMMANDS.keys());A.lines=0
	def addFunction(A,name,*C):
		B=name
		if B in A.COMMANDN:A.err(f"function {L(A.QUOTE+B+A.QUOTE,Z)} is already a command",A.lines)
		else:A.functions[B]=E.join(C)
	def reprun(A,code,times):
		for B in W(times):A.run(code,countLines=J)
	def setd(A,x,y,*D,typse=B,typstr=J):
		C=typse
		if typstr:C=G
		if type(y)==G and':'in y:y=y.split(':');y[0]=y[0][1:];E=A.variables[y[0]][1][B(y[1])];A.variables[x]=G,E;return
		if type(y)==G:
			if'$'in y:A.variables[x]=G,input(y[1:]+F.join(D));return
		try:
			if y[0]+y[1]=='__':C=G;y=y[2:]
		except:pass
		if C==B:
			try:y=B(y)
			except:A.err('Not an int',A.lines);return
		A.variables[x]=C,y
	def content(B,file):
		with N(file,U)as A:return A.read()
	def run(A,codeText,countLines=T):
		A.codeParts=[A.strip()for A in codeText.split(E)];A.lines+=B(countLines)
		if A.codeParts[0].strip()==F:return
		if A.codeParts[0]not in A.COMMANDN and A.codeParts[0]not in A.functions:
			if A.codeParts[0][0]=='#':
				if A.codeParts[0]=='#module':
					if M(A.codeParts)==1:A.err(f"No file given as module",A.lines)
					C=A.codeParts[1]
					try:G=N(C,U)
					except:
						if C[0]=='<'and C[-1]==S:
							try:G=N(b(__file__)+'/cendStandard/'+C[1:-1])
							except:A.err(f"File not found as module in standard library: {C}",A.lines)
						else:A.err(f"File not found as module: {C}",A.lines)
					I=G.read().split(O);G.close()
					for K in I:A.run(K,countLines=J)
				return
			A.err(f"Not a real command: {L(A.codeParts[0],Z)}",A.lines);return
		else:
			try:
				if A.codeParts[0]in A.COMMANDN:A.COMMANDS[A.codeParts[0]](*A.codeParts[1:])
				else:
					H=A.functions[A.codeParts[0]];H=H.split('|')
					for D in H:
						if D.strip()!=None:D=D.strip();A.run(D,countLines=J)
			except KeyboardInterrupt:A.err('KeyboardInterrupt',A.lines)
if __name__=='__main__':
	if M(K)==1:err('No input files');H(1)
	if M(K)==2 and K[1]=='-v':C(F)
	V=K[1:]
	try:Q=N(V[0],U)
	except:err('File not found');H(1)
	D=Q.read().split(O);D=[A.strip()for A in D];Q.close()
	if D[0].strip()!='#develop':A(f"Running {V[0]}...",'blue',attrs=[I])
	else:D=D[1:]
	e=d()
	for f in D:e.run(f)
	Q.close()